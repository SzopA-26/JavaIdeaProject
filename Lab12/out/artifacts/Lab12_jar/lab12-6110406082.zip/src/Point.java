public interface Point {
    double getPoint(Athlete player);
}
