package Dictionary;

public interface MyFormatter {
    String format(Object obj);
}
